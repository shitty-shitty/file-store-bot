improved by 
@rohit_1888
on Tg